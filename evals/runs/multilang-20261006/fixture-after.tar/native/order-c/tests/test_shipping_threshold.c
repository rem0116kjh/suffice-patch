#include "../include/quote.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    const uint64_t cases[][2] = {
        {1, 500}, {9999, 500}, {10000, 0}, {10001, 0}, {UINT64_MAX, 0}
    };
    order_quote result;
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
        const order_line line = {cases[i][0], 1};
        assert(make_quote(&line, 1, &result) == 0);
        assert(result.subtotal_cents == cases[i][0]);
        assert(result.shipping_cents == cases[i][1]);
        assert(result.total_cents == cases[i][0] + cases[i][1]);
    }
    const order_line aggregate[] = {{3000, 3}, {1000, 1}};
    assert(make_quote(aggregate, 2, &result) == 0);
    assert(result.subtotal_cents == 10000 && result.shipping_cents == 0 && result.total_cents == 10000);
    assert(aggregate[0].price_cents == 3000 && aggregate[0].quantity == 3);
    assert(aggregate[1].price_cents == 1000 && aggregate[1].quantity == 1);

    result = (order_quote){99, 99, 99};
    const order_line invalid[] = {{10000, 1}, {1, 0}};
    assert(make_quote(invalid, 2, &result) == -1);
    assert(result.subtotal_cents == 99 && result.shipping_cents == 99 && result.total_cents == 99);
    const order_line overflow[] = {{UINT64_MAX, 1}, {1, 1}};
    assert(make_quote(overflow, 2, &result) == -2);
    assert(result.subtotal_cents == 99 && result.shipping_cents == 99 && result.total_cents == 99);
    assert(make_quote(NULL, 1, &result) == -1);
    assert(make_quote(aggregate, 2, NULL) == -1);
    puts("C_THRESHOLD_OK groups=4 boundary_cases=5");
    return 0;
}
