package quote

import "testing"

func TestShippingThreshold(t *testing.T) {
	for _, tc := range []struct{ subtotal, shipping uint64 }{
		{1, 500}, {9999, 500}, {10000, 0}, {10001, 0}, {^uint64(0), 0},
	} {
		got, err := Calculate([]Line{{tc.subtotal, 1}})
		want := Quote{tc.subtotal, tc.shipping, tc.subtotal + tc.shipping}
		if err != nil || got != want {
			t.Fatalf("subtotal %d: got %+v, %v; want %+v", tc.subtotal, got, err, want)
		}
	}
}

func TestCheckedAggregateThreshold(t *testing.T) {
	lines := []Line{{3000, 3}, {1000, 1}}
	got, err := Calculate(lines)
	if err != nil || got != (Quote{10000, 0, 10000}) {
		t.Fatalf("%+v %v", got, err)
	}
	if lines[0] != (Line{3000, 3}) || lines[1] != (Line{1000, 1}) {
		t.Fatal("input changed")
	}
}

func TestFreeShippingStillValidates(t *testing.T) {
	for _, lines := range [][]Line{
		{{10000, 1}, {1, 0}},
		{{^uint64(0), 1}, {1, 1}},
	} {
		got, err := Calculate(lines)
		if err == nil || got != (Quote{}) {
			t.Fatalf("invalid order returned %+v, %v", got, err)
		}
	}
}
