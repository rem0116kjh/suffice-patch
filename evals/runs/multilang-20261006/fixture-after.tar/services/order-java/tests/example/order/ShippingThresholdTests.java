package example.order;
import java.util.List;

public final class ShippingThresholdTests {
    public static void main(String[] args) {
        long[][] cases = {{1, 500}, {9999, 500}, {10000, 0}, {10001, 0}, {Long.MAX_VALUE, 0}};
        for (long[] boundary : cases) {
            assert QuoteService.quote(List.of(new Line(boundary[0], 1))).equals(
                new QuoteService.Quote(boundary[0], boundary[1], boundary[0] + boundary[1]));
        }
        var lines = List.of(new Line(3000, 3), new Line(1000, 1));
        assert QuoteService.quote(lines).equals(new QuoteService.Quote(10000, 0, 10000));
        assert lines.equals(List.of(new Line(3000, 3), new Line(1000, 1)));

        boolean invalid = false;
        try {
            QuoteService.quote(List.of(new Line(10000, 1), new Line(1, 0)));
        } catch (IllegalArgumentException expected) { invalid = true; }
        assert invalid;
        boolean overflow = false;
        try {
            QuoteService.quote(List.of(new Line(Long.MAX_VALUE, 1), new Line(1, 1)));
        } catch (ArithmeticException expected) { overflow = true; }
        assert overflow;
        System.out.println("JAVA_THRESHOLD_OK groups=4 boundary_cases=5");
    }
}
