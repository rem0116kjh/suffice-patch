import test from "node:test";
import assert from "node:assert/strict";
import { quote } from "../src/quote.js";

for (const [subtotalCents, shippingCents] of [
  [1, 500], [9999, 500], [10000, 0], [10001, 0], [Number.MAX_SAFE_INTEGER, 0],
]) {
  test(`shipping for ${subtotalCents} cents`, () => {
    assert.deepEqual(quote([{ priceCents: subtotalCents, quantity: 1 }]), {
      subtotalCents, shippingCents, totalCents: subtotalCents + shippingCents,
    });
  });
}

test("threshold uses the checked aggregate without changing input", () => {
  const lines = Object.freeze([
    Object.freeze({ priceCents: 3000, quantity: 3 }),
    Object.freeze({ priceCents: 1000, quantity: 1 }),
  ]);
  assert.deepEqual(quote(lines), { subtotalCents: 10000, shippingCents: 0, totalCents: 10000 });
});

test("free shipping still validates later lines and aggregate overflow", () => {
  assert.throws(() => quote([
    { priceCents: 10000, quantity: 1 }, { priceCents: 1, quantity: 0 },
  ]), RangeError);
  assert.throws(() => quote([
    { priceCents: Number.MAX_SAFE_INTEGER, quantity: 1 }, { priceCents: 1, quantity: 1 },
  ]), RangeError);
});
